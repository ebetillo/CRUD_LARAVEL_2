<!DOCTYPE HTML >
<HTML>
   <HEAD>
   <meta charset="UTF-8">
   <link rel="stylesheet"  href="/css/app.css">
   </HEAD>
   <BODY>
     
     <div class="container">
        <h1>Publicaciones</h1>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="panel panel-default">
                <div class="panel-body">
                    <?php echo e($post->string); ?>

                </div>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

   
 
   </BODY>
</HTML>
<?php /**PATH C:\xampp\htdocs\CHRISTIAN_PALMA\resources\views//empleados/ws.blade.php ENDPATH**/ ?>