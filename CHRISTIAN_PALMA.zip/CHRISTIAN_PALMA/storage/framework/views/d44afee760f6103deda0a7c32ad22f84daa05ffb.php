Inicio(desplieque de datos)

<table class="table table-ligth">

    <thead class="thead-light">
   
    <tr>
     <th> ID <th>    
    <th> Codigo <th>
    <th> Nombre <th>
    <th> a_paterno <th>
    <th> a_materno <th>
    <th> puesto <th>
    <th> sueldo <th>
     <th> tipo_moneda_sueldo <th>
    <th> correo <th>
    <th> activo <th>
   <th> eliminado <th>
    </tr>
    </thread>

    <tbody>
    <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
     <td><?php echo e($loop-> iteration); ?> </td>
     <td><?php echo e($empleado -> id); ?> </td>
     <td><?php echo e($empleado -> codigo_empleado); ?> </td>
     <td><?php echo e($empleado -> Nombre); ?> </td>
     <td><?php echo e($empleado -> a_paterno); ?> </td>
     <td><?php echo e($empleado -> a_materno); ?> </td>
     <td><?php echo e($empleado -> puesto); ?> </td>
     <td><?php echo e($empleado -> sueldo); ?> </td>
     <td><?php echo e($empleado -> tipo_moneda_sueldo); ?> </td>
     <td><?php echo e($empleado -> correo); ?> </td>
     <td><?php echo e($empleado -> activo); ?> </td>
     <td><?php echo e($empleado -> eliminado); ?> </td>     
     <td> Inactivar |

    <form method="post" action="<?php echo e(url('/empleados/'.$empleado->id)); ?>">
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field('DELETE')); ?>

    <button type="submit" onclick="return confirm('Inactivar?');"> Inactivar </button>
    </form>

     </td>

     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table><?php /**PATH C:\xampp\htdocs\CHRISTIAN_PALMA\resources\views/empleados/index.blade.php ENDPATH**/ ?>