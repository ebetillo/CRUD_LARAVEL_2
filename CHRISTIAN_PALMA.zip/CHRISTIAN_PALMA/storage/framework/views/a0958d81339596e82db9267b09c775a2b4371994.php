Seccion para crear empleado
<form action="<?php echo e(url('/empleados')); ?>" method="post" enctype="multipart/form-data">
<?php echo e(csrf_field()); ?>


<label for="codigo_empleado"> <?php echo e('codigo_empleado'); ?></label>
<input type="text" name="codigo_empleado" id="codigo_empleado" value="">
<br>
<label for="Nombre"> <?php echo e('Nombre'); ?></label>
<input type="text" name="Nombre" id="Nombre" value="">
<br>
<label for="a_Paterno"> <?php echo e('a_Paterno'); ?></label>
<input type="text" name="a_Paterno" id="a_Paterno" value="">
<br>
<label for="a_Materno"> <?php echo e('a_Materno'); ?></label>
<input type="text" name="a_Materno" id="a_Materno" value="">
<br>
<label for="puesto"> <?php echo e('puesto'); ?></label>
<input type="text" name="puesto" id="puesto" value="">
<br>
<label for="sueldo"> <?php echo e('sueldo'); ?></label>
<input type="text" name="sueldo" id="sueldo" value="">
<br>
<label for="tipo_moneda_sueldo"> <?php echo e('tipo_moneda_sueldo'); ?></label>
<input type="text" name="tipo_moneda_sueldo" id="tipo_moneda_sueldo" value="">
<br>
<label for="correo"> <?php echo e('correo'); ?></label>
<input type="text" name="correo" id="correo" value="">
<br>
<label for="activo"> <?php echo e('activo'); ?></label>
<input type="text" name="activo" id="activo" value="">
<br>
<label for="eliminado"> <?php echo e('eliminado'); ?></label>
<input type="text" name="eliminado" id="eliminado" value="">
<br>
<input type="submit" value="Agrega">

</form>
<?php /**PATH C:\xampp\htdocs\CHRISTIAN_PALMA\resources\views/empleados/create.blade.php ENDPATH**/ ?>