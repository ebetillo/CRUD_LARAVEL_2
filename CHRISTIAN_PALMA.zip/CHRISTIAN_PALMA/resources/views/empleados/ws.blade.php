<!DOCTYPE HTML >
<HTML>
   <HEAD>
   <meta charset="UTF-8">
   <link rel="stylesheet"  href="/css/app.css">
   </HEAD>
   <BODY>
     
     <div class="container">
        <h1>Publicaciones</h1>
        @foreach ($posts as $post)
            <div class="panel panel-default">
                <div class="panel-body">
                    {{ $post->string}}
                </div>
            </div>

        @endforeach

    </div>

   
 
   </BODY>
</HTML>
