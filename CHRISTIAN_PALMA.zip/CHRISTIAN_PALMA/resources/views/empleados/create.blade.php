Seccion para crear empleado
<form action="{{url('/empleados')}}" method="post" enctype="multipart/form-data">
{{ csrf_field() }}

<label for="codigo_empleado"> {{'codigo_empleado'}}</label>
<input type="text" name="codigo_empleado" id="codigo_empleado" value="">
<br>
<label for="Nombre"> {{'Nombre'}}</label>
<input type="text" name="Nombre" id="Nombre" value="">
<br>
<label for="a_Paterno"> {{'a_Paterno'}}</label>
<input type="text" name="a_Paterno" id="a_Paterno" value="">
<br>
<label for="a_Materno"> {{'a_Materno'}}</label>
<input type="text" name="a_Materno" id="a_Materno" value="">
<br>
<label for="puesto"> {{'puesto'}}</label>
<input type="text" name="puesto" id="puesto" value="">
<br>
<label for="sueldo"> {{'sueldo'}}</label>
<input type="text" name="sueldo" id="sueldo" value="">
<br>
<label for="tipo_moneda_sueldo"> {{'tipo_moneda_sueldo'}}</label>
<input type="text" name="tipo_moneda_sueldo" id="tipo_moneda_sueldo" value="">
<br>
<label for="correo"> {{'correo'}}</label>
<input type="text" name="correo" id="correo" value="">
<br>
<label for="activo"> {{'activo'}}</label>
<input type="text" name="activo" id="activo" value="">
<br>
<label for="eliminado"> {{'eliminado'}}</label>
<input type="text" name="eliminado" id="eliminado" value="">
<br>
<input type="submit" value="Agrega">

</form>
