<?php

use Illuminate\Support\Facades\Route;
use GuzzleHttp\Client;


Route::get('/', function () {
    return view('welcome');
});

Route::get('/empleados/ws1', function () {

    $client = new Client([
        // Base URI is used with relative requests
        //'base_uri' => 'https://fx.currencysystem.com/webservices/CurrencyServer5.asmx/',
        // You can set any number of default request options.
        'timeout'  => 2.0,
    ]);
    
    $response = $client->request('GET', 'https://fx.currencysystem.com/webservices/CurrencyServer5.asmx/AllCurrencies?licenseKey=');
    
    //$posts = json_decode($response->getBody()->getContents());
    //return view('/empleados.ws1', compact('posts'));

    return $response->getBody()->getContents();
    
    //return view('/empleados.ws1');


});

Route::get('/empleados', function () {
    return view('empleados.index');
});

Route::get('/empleados/create', function () {
    return view('empleados.create');
});

Route::post('/empleados/create', function () {
    return view('empleados.store');
});

Route::resource('empleados','App\Http\Controllers\EmpleadosController');





//Route::resource('empleados','EmpleadosController');

//Route::get('/empleados/create','EmpleadosController@create');